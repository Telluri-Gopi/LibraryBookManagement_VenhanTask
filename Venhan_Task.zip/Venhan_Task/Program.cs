﻿using Microsoft.EntityFrameworkCore;
using Venhan_Task.AppDbContext;
using Venhan_Task.Repositories.Implemetation;
using Venhan_Task.Repositories.Interface;
using Venhan_Task.Services.Implementation;
using Venhan_Task.Services.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// 1. Configure Database Connection
// Make sure your appsettings.json has "DefaultConnection" — update it if needed (see below)
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// 2. Register repositories & services (update namespaces if necessary)
builder.Services.AddScoped<IBookRepository, BookRepository>();
builder.Services.AddScoped<IBorrowerRepository, BorrowerRepository>();
builder.Services.AddScoped<IBorrowRecordRepository, BorrowRecordRepository>();

builder.Services.AddScoped<IBorrowService, BorrowService>();

// 3. Controllers & Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// 4. CORS - allow Vite dev server origin and common localhost origins
var allowedOrigins = new[] { "http://localhost:5173", "http://localhost:5174", "http://localhost:3000", "http://localhost:5089" };
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: "AllowReactApp",
        policy =>
        {
            policy.WithOrigins(allowedOrigins)
                  .AllowAnyHeader()
                  .AllowAnyMethod();
                  
        });
});

var app = builder.Build();

// 5. Use Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

//app.UseHttpsRedirection();
app.UseCors("AllowReactApp");
app.UseAuthorization();
app.MapControllers();

app.Run();
