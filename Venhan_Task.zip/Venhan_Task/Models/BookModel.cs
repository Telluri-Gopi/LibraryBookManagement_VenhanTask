﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Venhan_Task.Models
{
    public class BookModel
    {

        [Key]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        public string Author { get; set; }
        public string? ISBN { get; set; }
        public string Genre { get; set; }
        // Total copies owned by library
        public int Quantity { get; set; }


        // Convenience - current available copies (not mapped)
        [NotMapped]
        public int Available { get; set; }
    }
}
