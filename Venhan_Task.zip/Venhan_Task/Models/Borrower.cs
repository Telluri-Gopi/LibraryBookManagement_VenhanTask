﻿using System.ComponentModel.DataAnnotations;

namespace Venhan_Task.Models
{
    public class Borrower
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public string Contact { get; set; }
        [Required]
        public string MembershipId { get; set; }
    }
}
