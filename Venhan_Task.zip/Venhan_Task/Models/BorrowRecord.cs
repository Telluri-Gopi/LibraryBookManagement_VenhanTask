﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Venhan_Task.Models
{
    public class BorrowRecord
    {
        [Key]
        public int Id { get; set; }


        [Required]
        public int BookId { get; set; }
        public BookModel Book { get; set; }


        [Required]
        public int BorrowerId { get; set; }
        public Borrower Borrower { get; set; }


        public DateTime BorrowedAt { get; set; }
        public DateTime DueAt { get; set; }
        public DateTime? ReturnedAt { get; set; }

        [NotMapped]
        public bool IsOverdue => ReturnedAt == null && DateTime.UtcNow > DueAt;
    }
}
