﻿using Microsoft.EntityFrameworkCore;
using Venhan_Task.Models;

namespace Venhan_Task.AppDbContext
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<BookModel> Books { get; set; }
        public DbSet<Borrower> Borrowers { get; set; }
        public DbSet<BorrowRecord> BorrowRecords { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Borrower>().HasIndex(b => b.MembershipId).IsUnique();
            // seed data or constraints if needed
        }

    }
}
