﻿using Venhan_Task.Models;
using Venhan_Task.Repositories.Implemetation;
using Venhan_Task.Repositories.Interface;
using Venhan_Task.Services.Interfaces;

namespace Venhan_Task.Services.Implementation
{
    public class BorrowService: IBorrowService
    {
        private readonly IBookRepository _bookRepo;
        private readonly IBorrowerRepository _borrowerRepo;
        private readonly IBorrowRecordRepository _recordRepo;

        public BorrowService(IBookRepository bookRepo, IBorrowerRepository borrowerRepo, IBorrowRecordRepository recordRepo)
        {
            _bookRepo = bookRepo; _borrowerRepo = borrowerRepo; _recordRepo = recordRepo;
        }

        public async Task<BorrowRecord> BorrowBookAsync(int bookId, int borrowerId, int days)
        {
            var book = await _bookRepo.GetByIdAsync(bookId);
            if (book == null) throw new Exception("Book not found");

            var borrower = await _borrowerRepo.GetByIdAsync(borrowerId);
            if (borrower == null) throw new Exception("Borrower not found");

            var borrowedCount = (await _recordRepo.GetActiveByBookIdAsync(bookId)).Count();
            var available = book.Quantity - borrowedCount;
            if (available <= 0) throw new Exception("No copies available");

            var record = new BorrowRecord
            {
                BookId = bookId,
                BorrowerId = borrowerId,
                BorrowedAt = DateTime.UtcNow,
                DueAt = DateTime.UtcNow.AddDays(days)
            };

            await _recordRepo.AddAsync(record);
            return record;
        }

        public async Task<IEnumerable<BorrowRecord>> GetBorrowedByBorrowerAsync(int borrowerId)
        {
            return await _recordRepo.GetByBorrowerIdAsync(borrowerId);
        }

        public async Task<IEnumerable<BorrowRecord>> GetOverdueAsync()
        {
            var all = await _recordRepo.GetAllAsync();
            return all.Where(r => r.ReturnedAt == null && r.DueAt < DateTime.UtcNow);
        }

        public async Task ReturnBookAsync(int borrowRecordId)
        {
            var record = await _recordRepo.GetByIdAsync(borrowRecordId);
            if (record == null) throw new Exception("Borrow record not found");
            if (record.ReturnedAt != null) throw new Exception("Already returned");

            record.ReturnedAt = DateTime.UtcNow;
            await _recordRepo.UpdateAsync(record);
        }
    }
}
