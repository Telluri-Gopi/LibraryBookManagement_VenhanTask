﻿using Venhan_Task.Models;

namespace Venhan_Task.Services.Interfaces
{
    public interface IBorrowService
    {
        Task<BorrowRecord> BorrowBookAsync(int bookId, int borrowerId, int days);
        Task ReturnBookAsync(int borrowRecordId);
        Task<IEnumerable<BorrowRecord>> GetBorrowedByBorrowerAsync(int borrowerId);
        Task<IEnumerable<BorrowRecord>> GetOverdueAsync();
    }
}
