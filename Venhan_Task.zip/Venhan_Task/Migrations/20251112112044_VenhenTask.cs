﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Venhan_Task.Migrations
{
    /// <inheritdoc />
    public partial class VenhenTask : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "MembershipId",
                table: "Borrowers",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateIndex(
                name: "IX_Borrowers_MembershipId",
                table: "Borrowers",
                column: "MembershipId",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Borrowers_MembershipId",
                table: "Borrowers");

            migrationBuilder.AlterColumn<string>(
                name: "MembershipId",
                table: "Borrowers",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");
        }
    }
}
