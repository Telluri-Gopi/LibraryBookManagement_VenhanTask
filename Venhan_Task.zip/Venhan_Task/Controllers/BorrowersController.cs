﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Venhan_Task.Models;
using Venhan_Task.Repositories.Interface;

namespace Venhan_Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BorrowersController : ControllerBase
    {
        private readonly IBorrowerRepository _repo;
        public BorrowersController(IBorrowerRepository repo) { _repo = repo; }

        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _repo.GetAllAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var b = await _repo.GetByIdAsync(id);
            if (b == null) return NotFound();
            return Ok(b);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Borrower borrower)
        {
            await _repo.AddAsync(borrower);
            return CreatedAtAction(nameof(Get), new { id = borrower.Id }, borrower);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Borrower borrower)
        {
            var existing = await _repo.GetByIdAsync(id);
            if (existing == null) return NotFound();
            borrower.Id = id;
            await _repo.UpdateAsync(borrower);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }

        [HttpGet("byMembership/{membershipId}")]
        public async Task<IActionResult> GetByMembership(string membershipId)
        {
            var borrower = await _repo.GetByMembershipIdAsync(membershipId);

            if (borrower == null)
                return NotFound(new { message = "Borrower not found" });

            return Ok(borrower);
        }

    }
}
