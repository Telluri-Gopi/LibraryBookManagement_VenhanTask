﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Venhan_Task.Models;
using Venhan_Task.Repositories.Interface;

namespace Venhan_Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookRepository _repo;
        private readonly IBorrowRecordRepository _recordRepo;
        public BookController(IBookRepository repo, IBorrowRecordRepository recordRepo) { _repo = repo; _recordRepo = recordRepo; }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var books = (await _repo.GetAllAsync()).ToList();
            foreach (var b in books)
            {
                var borrowed = (await _recordRepo.GetActiveByBookIdAsync(b.Id)).Count();
                b.Available = b.Quantity - borrowed;
            }
            return Ok(books);
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string? q)
        {
            var books = (await _repo.SearchAsync(q)).ToList();
            foreach (var b in books)
            {
                var borrowed = (await _recordRepo.GetActiveByBookIdAsync(b.Id)).Count();
                b.Available = b.Quantity - borrowed;
            }
            return Ok(books);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var b = await _repo.GetByIdAsync(id);
            if (b == null) return NotFound();
            var borrowed = (await _recordRepo.GetActiveByBookIdAsync(b.Id)).Count();
            b.Available = b.Quantity - borrowed;
            return Ok(b);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] BookModel book)
        {

            if (string.IsNullOrEmpty(book.ISBN))
            {
                book.ISBN = Guid.NewGuid().ToString().Substring(0, 8);
            }
            await _repo.AddAsync(book);
            return CreatedAtAction(nameof(Get), new { id = book.Id }, book);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] BookModel book)
        {
            var existing = await _repo.GetByIdAsync(id);
            if (existing == null) return NotFound();
            book.Id = id;
            await _repo.UpdateAsync(book);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }
    }
}
