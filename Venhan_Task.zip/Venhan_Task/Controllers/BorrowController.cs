﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Venhan_Task.Services.Interfaces;

namespace Venhan_Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BorrowController : ControllerBase
    {
        private readonly IBorrowService _service;
        public BorrowController(IBorrowService service) { _service = service; }

        [HttpPost("borrow")]
        public async Task<IActionResult> Borrow([FromQuery] int bookId, [FromQuery] int borrowerId, [FromQuery] int days = 14)
        {
            try
            {
                var record = await _service.BorrowBookAsync(bookId, borrowerId, days);
                return Ok(record);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("return")]
        public async Task<IActionResult> Return([FromQuery] int recordId)
        {
            try
            {
                await _service.ReturnBookAsync(recordId);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("borrower/{borrowerId}")]
        public async Task<IActionResult> GetByBorrower(int borrowerId)
        {
            var data = await _service.GetBorrowedByBorrowerAsync(borrowerId);
            return Ok(data);
        }

        [HttpGet("overdue")]
        public async Task<IActionResult> GetOverdue()
        {
            var data = await _service.GetOverdueAsync();
            return Ok(data);
        }
    }
}
