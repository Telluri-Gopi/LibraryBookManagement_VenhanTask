﻿using Venhan_Task.Models;

namespace Venhan_Task.Repositories.Interface
{
    public interface IBorrowerRepository
    {
        Task<Borrower?> GetByIdAsync(int id);
        Task<Borrower?> GetByMembershipIdAsync(string membershipId);
        Task<IEnumerable<Borrower>> GetAllAsync();
        Task AddAsync(Borrower borrower);
        Task UpdateAsync(Borrower borrower);
        Task DeleteAsync(int id);
    }
}
