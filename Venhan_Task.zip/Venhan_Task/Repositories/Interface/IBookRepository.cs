﻿using Venhan_Task.Models;

namespace Venhan_Task.Repositories.Interface
{
    public interface IBookRepository
    {
        Task<BookModel> GetByIdAsync(int id);
        Task<IEnumerable<BookModel>> GetAllAsync();
        Task<IEnumerable<BookModel>> SearchAsync(string query);
        Task AddAsync(BookModel book);
        Task UpdateAsync(BookModel book);
        Task DeleteAsync(int id);
    }
}
