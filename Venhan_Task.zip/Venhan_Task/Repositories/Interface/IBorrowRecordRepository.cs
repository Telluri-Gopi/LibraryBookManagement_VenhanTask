﻿using Venhan_Task.Models;

namespace Venhan_Task.Repositories.Interface
{
    public interface IBorrowRecordRepository
    {
        Task<BorrowRecord?> GetByIdAsync(int id);
        Task<IEnumerable<BorrowRecord>> GetActiveByBookIdAsync(int bookId);
        Task<IEnumerable<BorrowRecord>> GetByBorrowerIdAsync(int borrowerId);
        Task<IEnumerable<BorrowRecord>> GetAllAsync();
        Task AddAsync(BorrowRecord record);
        Task UpdateAsync(BorrowRecord record);
    }
}
