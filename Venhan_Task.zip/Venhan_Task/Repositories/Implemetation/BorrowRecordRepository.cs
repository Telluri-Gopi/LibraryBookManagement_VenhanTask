﻿using Microsoft.EntityFrameworkCore;
using Venhan_Task.AppDbContext;
using Venhan_Task.Models;
using Venhan_Task.Repositories.Interface;

namespace Venhan_Task.Repositories.Implemetation
{
    public class BorrowRecordRepository: IBorrowRecordRepository
    {
        private readonly ApplicationDbContext _db;

        public BorrowRecordRepository(ApplicationDbContext context)
        {
            _db = context;
        }

        public async Task AddAsync(BorrowRecord record)
        {
            await _db.BorrowRecords.AddAsync(record);
            await _db.SaveChangesAsync();
        }

        public async Task<IEnumerable<BorrowRecord>> GetActiveByBookIdAsync(int bookId)
        {
            return await _db.BorrowRecords.Where(r => r.BookId == bookId && r.ReturnedAt == null).ToListAsync();
        }

        public async Task<IEnumerable<BorrowRecord>> GetAllAsync()
        {
            return await _db.BorrowRecords.Include(r => r.Book).Include(r => r.Borrower).ToListAsync();
        }

        public async Task<IEnumerable<BorrowRecord>> GetByBorrowerIdAsync(int borrowerId)
        {
            return await _db.BorrowRecords.Where(r => r.BorrowerId == borrowerId).ToListAsync();
        }

        public async Task<BorrowRecord?> GetByIdAsync(int id)
        {
            return await _db.BorrowRecords.Include(r => r.Book).Include(r => r.Borrower).FirstOrDefaultAsync(r => r.Id == id);
        }

        public async Task UpdateAsync(BorrowRecord record)
        {
            _db.BorrowRecords.Update(record);
            await _db.SaveChangesAsync();
        }
    }
}
