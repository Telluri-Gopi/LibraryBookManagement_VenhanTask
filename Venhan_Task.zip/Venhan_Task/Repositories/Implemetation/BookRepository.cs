﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Venhan_Task.AppDbContext;
using Venhan_Task.Models;
using Venhan_Task.Repositories.Interface;

namespace Venhan_Task.Repositories.Implemetation
{
    public class BookRepository:IBookRepository
    {
        private readonly ApplicationDbContext _context;

        public BookRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task AddAsync(BookModel book)
        {
            await _context.Books.AddAsync(book);
            await _context.SaveChangesAsync();

        }

        public async Task DeleteAsync(int id)
        {
           var b= await _context.Books.FindAsync(id);
            if (b == null) return;
            _context.Books.Remove(b);
            await _context.SaveChangesAsync();
           

        }

        public async Task<IEnumerable<BookModel>> GetAllAsync()
        {
            return await _context.Books.ToListAsync();
        }

        public async Task<BookModel> GetByIdAsync(int id)
        {
            return await _context.Books.FindAsync(id);

        }

        public async Task<IEnumerable<BookModel>> SearchAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return await GetAllAsync();


            query = query.ToLower();
            return await _context.Books
            .Where(x => x.Title.ToLower().Contains(query)
            || x.Author.ToLower().Contains(query)
            || x.Genre.ToLower().Contains(query))
            .ToListAsync();
        }

        public async Task UpdateAsync(BookModel book)
        {
            _context.Books.Update(book);
            await _context.SaveChangesAsync();
        }
    }
}
