﻿using Microsoft.EntityFrameworkCore;
using Venhan_Task.AppDbContext;
using Venhan_Task.Models;
using Venhan_Task.Repositories.Interface;

namespace Venhan_Task.Repositories.Implemetation
{
    public class BorrowerRepository : IBorrowerRepository
    {
        private readonly ApplicationDbContext _db;

        public BorrowerRepository(ApplicationDbContext context)
        {
            _db = context;
        }

        public async Task AddAsync(Borrower borrower)
        {
            await _db.Borrowers.AddAsync(borrower);
            await _db.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var b = await _db.Borrowers.FindAsync(id);
            if (b == null) return;
            _db.Borrowers.Remove(b);
            await _db.SaveChangesAsync();
        }

        public async Task<IEnumerable<Borrower>> GetAllAsync()
        {
            return await _db.Borrowers.ToListAsync();
        }

        public async Task<Borrower?> GetByIdAsync(int id)
        {
            return await _db.Borrowers.FindAsync(id);
        }

        public async Task<Borrower?> GetByMembershipIdAsync(string membershipId)
        {
            return await _db.Borrowers.FirstOrDefaultAsync(b => b.MembershipId == membershipId);
        }

        public async Task UpdateAsync(Borrower borrower)
        {
            _db.Borrowers.Update(borrower);
            await _db.SaveChangesAsync();
        }
    }
}
