import React, { useEffect, useState } from "react";

const BookList = () => {
  const [books, setBooks] = useState([]);
  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    genre: "",
    quantity: "",
  });

  // Load all books
  const fetchBooks = () => {
    fetch("http://localhost:5089/api/Book")

      .then((res) => res.json())
      .then((data) => setBooks(data))
      .catch((err) => console.error("Error fetching books:", err));
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  // Handle form input
  const handleChange = (e) => {
    setNewBook({ ...newBook, [e.target.name]: e.target.value });
  };

  // Add book API call
  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:5089/api/Book"
, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newBook),
    })
      .then((res) => {
        if (res.ok) {
          alert("Book added successfully!");
          setNewBook({ title: "", author: "", genre: "", quantity: "" });
          fetchBooks(); // refresh list
        } else {
          alert("Error adding book");
        }
      })
      .catch(() => alert("Error connecting to API"));
  };

  return (
    <div className="container">
      <h2>📚 Library Books</h2>

      {/* ADD BOOK FORM */}
      <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
        <h3>Add New Book</h3>
        <input
          type="text"
          name="title"
          placeholder="Title"
          value={newBook.title}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="author"
          placeholder="Author"
          value={newBook.author}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="genre"
          placeholder="Genre"
          value={newBook.genre}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="quantity"
          placeholder="Quantity"
          value={newBook.quantity}
          onChange={handleChange}
          required
        />
        <button type="submit">Add Book</button>
      </form>

      {/* BOOK LIST */}
      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
          {books.length > 0 ? (
            books.map((book) => (
              <tr key={book.id}>
                <td>{book.title}</td>
                <td>{book.author}</td>
                <td>{book.genre}</td>
                <td>{book.quantity}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4">No books available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default BookList;
