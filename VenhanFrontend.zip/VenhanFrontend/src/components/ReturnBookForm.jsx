import React, { useState } from "react";
import { returnBook } from "../api";

const ReturnBookForm = () => {
  const [membershipId, setMembershipId] = useState("");
  const [bookId, setBookId] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await returnBook(membershipId, bookId);
      alert("Book returned successfully!");

      setMembershipId("");
      setBookId("");
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="container">
      <h2>🔄 Return a Book</h2>
      <form onSubmit={handleSubmit}>
        <input
          placeholder="Membership ID"
          value={membershipId}
          onChange={(e) => setMembershipId(e.target.value)}
          required
        />

        <input
          placeholder="Book ID"
          value={bookId}
          onChange={(e) => setBookId(e.target.value)}
          required
        />

        <button type="submit">Return</button>
      </form>
    </div>
  );
};

export default ReturnBookForm;
