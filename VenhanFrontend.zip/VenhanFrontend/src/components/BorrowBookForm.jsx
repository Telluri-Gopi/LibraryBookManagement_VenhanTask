import React, { useState } from "react";
import { borrowBook } from "../api";

const BorrowBookForm = () => {
  const [membershipId, setMembershipId] = useState("");
  const [bookId, setBookId] = useState("");
  const [days, setDays] = useState(14);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await borrowBook(membershipId, bookId, days);
      alert("Book borrowed successfully!");
      setMembershipId("");
      setBookId("");
      setDays(14);
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="container">
      <h2>📖 Borrow a Book</h2>
      <form onSubmit={handleSubmit}>
        <input
          placeholder="Membership ID"
          value={membershipId}
          onChange={(e) => setMembershipId(e.target.value)}
          required
        />

        <input
          placeholder="Book ID"
          value={bookId}
          onChange={(e) => setBookId(e.target.value)}
          required
        />

        <input
          type="number"
          placeholder="Days"
          value={days}
          onChange={(e) => setDays(e.target.value)}
          required
        />

        <button type="submit">Borrow</button>
      </form>
    </div>
  );
};

export default BorrowBookForm;
