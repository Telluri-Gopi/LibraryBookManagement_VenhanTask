// src/components/BorrowerList.js
import React, { useEffect, useState } from "react";
import { getBorrowers } from "../api";

const BorrowerList = () => {
  const [borrowers, setBorrowers] = useState([]);

  useEffect(() => {
    getBorrowers().then((res) => setBorrowers(res.data));
  }, []);

  return (
    <div className="container">
      <h2>👤 Borrowers</h2>
      <table border="1" cellPadding="10">
        <thead>
          <tr><th>Name</th><th>Membership ID</th><th>Contact</th></tr>
        </thead>
        <tbody>
          {borrowers.map((b) => (
            <tr key={b.id}>
              <td>{b.name}</td>
              <td>{b.membershipId}</td>
              <td>{b.contact}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BorrowerList;
