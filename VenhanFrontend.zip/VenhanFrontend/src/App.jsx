// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import BookList from "./components/BookList";
import BorrowerList from "./components/BorrowerList";
import  BorrowBookForm from "./components/BorrowBookForm";
import ReturnBookForm  from "./components/ReturnBookForm";
import "./App.css";

function App() {
  return (
    <Router>
      <nav className="navbar">
        <Link to="/">Books</Link>
        <Link to="/borrowers">Borrowers</Link>
        <Link to="/borrow">Borrow</Link>
        <Link to="/return">Return</Link>
      </nav>

      <Routes>
        <Route path="/" element={<BookList />} />
        <Route path="/borrowers" element={<BorrowerList />} />
        <Route path="/borrow" element={<BorrowBookForm />} />
        <Route path="/return" element={<ReturnBookForm />} />
      </Routes>
    </Router>
  );
}

export default App;
