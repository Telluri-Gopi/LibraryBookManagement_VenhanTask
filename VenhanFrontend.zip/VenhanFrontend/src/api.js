import axios from "axios";

const API_BASE = "http://localhost:5089/api";

// ✅ Get all borrowers
export const getBorrowers = () => {
  return axios.get(`${API_BASE}/Borrowers`);
};

// ✅ Borrow a book
export const borrowBook = async (membershipId, bookId, days = 14) => {
  const borrowerRes = await axios.get(`${API_BASE}/Borrowers/byMembership/${membershipId}`);
  const borrower = borrowerRes.data;

  if (!borrower || !borrower.id) {
    throw new Error("Borrower not found");
  }

  return axios.post(
    `${API_BASE}/Borrow?bookId=${bookId}&borrowerId=${borrower.id}&days=${days}`
  );
};


// ✅ Return a book
export const returnBook = async (membershipId, bookId) => {
  const borrowerRes = await axios.get(`${API_BASE}/Borrowers/byMembership/${membershipId}`);
  const borrower = borrowerRes.data;

  if (!borrower || !borrower.id) {
    throw new Error("Borrower not found");
  }

  const recordsRes = await axios.get(`${API_BASE}/Borrow/borrower/${borrower.id}`);
  const records = recordsRes.data;

  const activeRecord = records.find(
    (r) => r.bookId === parseInt(bookId) && r.isReturned === false
  );

  if (!activeRecord) {
    throw new Error("No active borrow record found for this borrower and book");
  }

  return axios.post(`${API_BASE}/Borrow/return?recordId=${activeRecord.id}`);
};
